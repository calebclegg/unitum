"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.posts = void 0;
exports.posts = [
    {
        body: "New Post 1"
    },
    {
        body: "All about Django"
    },
    {
        body: "Typescript"
    }
];
